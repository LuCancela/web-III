<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Padaria extends Model
{
    //
    protected $table = 'tbLanche';
    // fazendo com que o laravel tenha acesso a tabela do banco 
}

